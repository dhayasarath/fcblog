<?php
class Common extends CI_Model
{

    /***********************************insert data***************************************/
    public function item_insert($table,$datas)
    {
        $this->db->insert($table,$datas);
        $id = $this->db->insert_id();
        return $id;
    }

    /***********************************update data***************************************/
    public function update_one_item($id,$field,$table,$dataeditems)
    {
        $this->db->where($field,$id);
        $this->db->update($table,$dataeditems);
        return ($this->db->affected_rows() > 0);
    }


    /***********************************select according to one field data***************************************/
    public function get_one_item($table,$field1,$value1)
    {
        $this->db->where($field1,$value1);
        $query = $this->db->get($table);
        $res=$query->result();
        return $res;
    }

    /***********************************select according to two field data***************************************/
    public function get_two_item($table,$field1,$value1,$field2,$value2)
    {
        $this->db->where($field1,$value1);
        $this->db->where($field2,$value2);
        $query = $this->db->get($table);
        $res=$query->result();
        return $res;
    }

    /***********************************select according to field data descending***************************************/
    public function get_all_desc($table,$field)
    {
        $this->db->order_by($field,'desc');
        $query = $this->db->get($table);
        $res=$query->result();
        return $res;
    }

    public function get_left_join_descc($perpage='',$offset='')
    {
        $this->db->select('*');
        $this->db->from('blog_post');
        $this->db->join('users', 'users.user_id = blog_post.user_id', 'left');
        $this->db->limit($perpage,$offset);
        $query = $this->db->get();
        $res=$query->result();
        return $res;
    }

    public function get_left_join_desc($table1,$col1,$table2,$col2,$field,$perpage='',$offset='')
    {
        $this->db->select('*');
        $this->db->from($table1);
        $this->db->join($table2, $col2 = $col1, 'left');
        $this->db->order_by($field,'desc');
        $this->db->limit($perpage,$offset);
        $query = $this->db->get();
        $res=$query->result();
        return $res;
    }

    public function get_one_item_left_join($table1,$col1,$table2,$col2,$field,$value)
    {
        $this->db->select('*');
        $this->db->from($table1);
        $this->db->join($table2,$col1 = $col2,'left');
        $this->db->where($field,$value);
        $query = $this->db->get();
        $res=$query->result();
        return $res;
    }

}